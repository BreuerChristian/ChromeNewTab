# ChromeNewTab
a Black new chrome Tab 

https://chromewebstore.google.com/detail/joobkcebnlddbnndallipbdhcolglgno

