# ChromeNewTab
a Black new chrome Tab 

https://chromewebstore.google.com/detail/joobkcebnlddbnndallipbdhcolglgno

---

## Ko‑fi brand assets
This extension uses the Ko‑fi brand icon and wordmark (color) in the toolbar popup. Assets sourced from https://more.ko-fi.com/brand-assets and used according to Ko‑fi brand guidelines.

